package com.hieu.zk_example.services;

import java.util.List;


import com.hieu.zk_example.entity.Product;

public interface ProductService {
	List<Product> getList();

}
